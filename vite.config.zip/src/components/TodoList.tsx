import React from 'react';
import { IonList } from '@ionic/react';
import TodoItem from './TodoItem';

interface TodoListProps {
  todos: { id: number; task: string; completed: boolean }[];
  onToggleComplete: (id: number, completed: boolean) => void;
  onEdit: (id: number, newTask: string) => void;
  onDelete: (id: number) => void;
}

const TodoList: React.FC<TodoListProps> = ({ todos, onToggleComplete, onEdit, onDelete }) => {
  return (
    <IonList>
      {todos.map(todo => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggleComplete={onToggleComplete}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      ))}
    </IonList>
  );
};

export default TodoList;
