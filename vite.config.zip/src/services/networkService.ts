import { Network } from '@capacitor/network';
import { getTodosFromLocal, saveTodoToLocal, updateTodoLocal, deleteTodoLocal } from './localStorage';
import { createTodo, updateTodo, deleteTodo, toggleComplete } from './todoService';

// Función para verificar si estamos conectados a la red
export const checkConnection = async () => {
  const status = await Network.getStatus();
  return status.connected;
};

// Sincronizar datos locales con la API cuando se tiene conexión
export const syncWithAPI = async () => {
  const connection = await checkConnection();

  if (connection) {
    const localTodos = await getTodosFromLocal();

    // Verificamos si `localTodos` no es undefined ni null
    if (localTodos && Array.isArray(localTodos)) {
      for (let todo of localTodos) {
        // Si la tarea está marcada como no sincronizada, la sincronizamos con la API
        if (!todo.synced) {
          try {
            if (todo.id) {
              // Si la tarea tiene un ID, la actualizamos
              await updateTodo(todo.id, todo.task);
            } else {
              // Si no tiene un ID, la creamos
              const createdTodo = await createTodo(todo.task);
              // Guardamos el ID retornado por la API en la base de datos local
              await updateTodoLocal(todo.id, createdTodo.id);
            }
            // Una vez sincronizada, marcamos como sincronizada
            await updateTodoLocal(todo.id, todo.task, true);
          } catch (error) {
            console.error("Error syncing todo", error);
          }
        }
      }
    }
  }
};
