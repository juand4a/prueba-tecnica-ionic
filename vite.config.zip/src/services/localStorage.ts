import { CapacitorSQLite } from '@capacitor-community/sqlite';

let db: any; // Variable global para la base de datos

// Función para abrir o crear la base de datos
const openDatabase = async () => {
  if (!db) { // Solo abrir la base de datos si no está abierta
    const dbName = "tasksDB"; // Nombre de la base de datos

    try {
      // Abrir la base de datos si ya existe, o crear una nueva si no existe
      const result = await CapacitorSQLite.open({ database: dbName });

      // Guardar la referencia a la base de datos en la variable global
      db = result;
      console.log('Base de datos abierta correctamente');
    } catch (error) {
      console.error('Error al abrir la base de datos:', error);
      throw error; // Lanza el error para manejarlo en otro lugar
    }
  }
};

// Crear la tabla
export const createTable = async () => {
  try {
    await openDatabase(); // Asegúrate de que la base de datos esté abierta
    const query = 'CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, task TEXT, completed BOOLEAN, synced BOOLEAN)';
    await db.query({ statement: query });
    console.log('Tabla de tareas creada o ya existe');
  } catch (error) {
    console.error('Error al crear la tabla:', error);
  }
};
// Guardar una tarea
export const saveTodoToLocal = async (task: string) => {
  try {
    await openDatabase(); // Asegúrate de que la base de datos esté abierta
    const query = `INSERT INTO tasks (task, completed, synced) VALUES ("${task}", false, false)`;
    await db.query({ statement: query });
    console.log('Tarea guardada');
  } catch (error) {
    console.error('Error al guardar la tarea:', error);
  }
};

// Obtener todas las tareas
export const getTodosFromLocal = async () => {
  try {
    await openDatabase(); // Asegúrate de que la base de datos esté abierta
    const query = 'SELECT * FROM tasks';
    const result = await db.query({ statement: query });
    if (result && Array.isArray(result.values)) {
      return result.values; // Si el resultado tiene valores, devuelve ese arreglo
    } else {
      return []; // Si no hay tareas, retornar un arreglo vacío
    }
  } catch (error) {
    console.error('Error al obtener las tareas:', error);
    return []; // Si ocurre un error, retornar un arreglo vacío
  }
};

// Actualizar una tarea
export const updateTodoLocal = async (id: number, task: string, synced: boolean = false) => {
  try {
    await openDatabase(); // Asegúrate de que la base de datos esté abierta
    const query = `UPDATE tasks SET task = "${task}", synced = ${synced} WHERE id = ${id}`;
    await db.query({ statement: query });
    console.log('Tarea actualizada');
  } catch (error) {
    console.error('Error al actualizar la tarea:', error);
  }
};

// Eliminar una tarea
export const deleteTodoLocal = async (id: number) => {
  try {
    await openDatabase(); // Asegúrate de que la base de datos esté abierta
    const query = `DELETE FROM tasks WHERE id = ${id}`;
    await db.query({ statement: query });
    console.log('Tarea eliminada');
  } catch (error) {
    console.error('Error al eliminar la tarea:', error);
  }
};

// Marcar tarea como completada o no completada
export const toggleCompleteLocal = async (id: number, completed: boolean) => {
  try {
    await openDatabase(); // Asegúrate de que la base de datos esté abierta
    const query = `UPDATE tasks SET completed = ${completed} WHERE id = ${id}`;
    await db.query({ statement: query });
    console.log('Estado de tarea actualizado');
  } catch (error) {
    console.error('Error al actualizar el estado de la tarea:', error);
  }
};
