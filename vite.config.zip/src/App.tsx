import React from 'react';
import { IonApp, IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/react';
import Home from './pages/Home';
import '@ionic/react/css/core.css';

const App: React.FC = () => (
  <IonApp>
    <IonHeader>
      <IonToolbar>
        <IonTitle>To-Do List</IonTitle>
      </IonToolbar>
    </IonHeader>
    <IonContent>
      <Home />
    </IonContent>
  </IonApp>
);

export default App;
