import React, { useState, useEffect } from 'react';
import { IonContent, IonButton, IonInput, IonList, IonItem, IonLabel, IonCheckbox, IonToast } from '@ionic/react';
import { createTodo, getTodos, updateTodo, deleteTodo, toggleComplete } from '../services/todoService';
import { createTable, getTodosFromLocal, saveTodoToLocal, updateTodoLocal, deleteTodoLocal, toggleCompleteLocal } from '../services/localStorage';
import { syncWithAPI } from '../services/networkService';

const Home: React.FC = () => {
  const [task, setTask] = useState('');
  const [todos, setTodos] = useState<any[]>([]);
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    // Crear la tabla y cargar las tareas al iniciar
    createTable();
    loadTodos();

    // Intentar sincronizar con la API cada vez que la conexión esté disponible
    syncWithAPI();
  }, []);

  const loadTodos = async () => {
    try {
      // Cargar tareas desde la base de datos local
      let localTodos = await getTodosFromLocal();
      console.log('Local tasks fetched:', localTodos);  // Debugging line

      if (localTodos && localTodos.length > 0) {
        setTodos(localTodos); // Si existen tareas locales, las establecemos en el estado
      } else {
        // Si no hay tareas locales, cargar desde la API
        const apiTodos = await getTodos();
        setTodos(apiTodos); // Establecer tareas obtenidas de la API
      }
    } catch (error) {
      console.error('Error al cargar tareas:', error);
    }
  };

  const handleCreate = async () => {
    if (task.trim()) {
      // Guardar la tarea localmente
      await saveTodoToLocal(task);
      setTask('');
      loadTodos();  // Recargar tareas
      setShowToast(true);

      // Luego guardarla en la API
      await createTodo(task);
    }
  };

  const handleDelete = async (id: number) => {
    await deleteTodoLocal(id);
    loadTodos(); // Recargar tareas

    await deleteTodo(id); // Sincronizar con la API
  };

  const handleToggleComplete = async (id: number, completed: boolean) => {
    await toggleCompleteLocal(id, !completed);
    loadTodos(); // Recargar tareas

    await toggleComplete(id, !completed); // Sincronizar con la API
  };

  const handleEdit = async (id: number, newTask: string) => {
    await updateTodoLocal(id, newTask);
    loadTodos(); // Recargar tareas

    await updateTodo(id, newTask); // Sincronizar con la API
  };

  return (
    <IonContent>
      <IonToast
        isOpen={showToast}
        message="Task added successfully!"
        duration={2000}
        onDidDismiss={() => setShowToast(false)}
      />
      <IonInput
        value={task}
        onIonChange={(e) => setTask(e.detail.value!)}
        placeholder="Enter task"
      />
      <IonButton onClick={handleCreate}>Add Task</IonButton>
      <IonList>
        {todos.length === 0 ? (
          <IonItem>No tasks available</IonItem>
        ) : (
          todos.map((todo: any) => (
            <IonItem key={todo.id}>
              <IonLabel>{todo.task}</IonLabel>
              <IonCheckbox
                checked={todo.completed}
                onIonChange={() => handleToggleComplete(todo.id, todo.completed)}
              />
              <IonButton onClick={() => handleEdit(todo.id, 'New Task Name')}>Edit</IonButton>
              <IonButton color="danger" onClick={() => handleDelete(todo.id)}>Delete</IonButton>
            </IonItem>
          ))
        )}
      </IonList>
    </IonContent>
  );
};

export default Home;
